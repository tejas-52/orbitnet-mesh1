import { cn } from '@/lib/utils';
import { Rocket, Play, Pause, RotateCcw, Satellite } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';

interface MissionHeaderProps {
  isRunning: boolean;
  onToggleRunning: () => void;
  onReset: () => void;
  missionTime: number;
  orbitnetEnabled: boolean;
  onToggleOrbitnet: () => void;
}

export function MissionHeader({
  isRunning,
  onToggleRunning,
  onReset,
  missionTime,
  orbitnetEnabled,
  onToggleOrbitnet,
}: MissionHeaderProps) {
  const formatMissionTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `T+${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <header className="bg-card/80 backdrop-blur-sm border-b border-border sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo & Title */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
                <Satellite className="w-6 h-6 text-primary" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-success rounded-full border-2 border-card animate-pulse" />
            </div>
            <div>
              <h1 className="font-display text-xl font-bold tracking-tight text-foreground">
                ORBITNET-MESH
              </h1>
              <p className="text-xs text-muted-foreground">
                Space Transportation Communication Relay System
              </p>
            </div>
          </div>

          {/* Mission Timer */}
          <div className="hidden md:flex items-center gap-6">
            <div className="text-center">
              <div className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                Mission Elapsed Time
              </div>
              <div className="font-mono text-2xl text-primary font-bold tracking-wider">
                {formatMissionTime(missionTime)}
              </div>
            </div>

            {/* ORBITNET Toggle */}
            <div className="flex items-center gap-3 bg-secondary/50 rounded-lg px-4 py-2 border border-border">
              <span className={cn(
                'text-xs font-medium uppercase tracking-wide',
                orbitnetEnabled ? 'text-primary' : 'text-muted-foreground'
              )}>
                ORBITNET-MESH
              </span>
              <Switch
                checked={orbitnetEnabled}
                onCheckedChange={onToggleOrbitnet}
                className="data-[state=checked]:bg-primary"
              />
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2">
            <Button
              onClick={onToggleRunning}
              className={cn(
                'btn-mission gap-2',
                isRunning && 'bg-success/10 border-success/30 text-success hover:bg-success/20'
              )}
            >
              {isRunning ? (
                <>
                  <Pause className="w-4 h-4" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Start
                </>
              )}
            </Button>
            <Button
              onClick={onReset}
              variant="outline"
              className="border-border hover:bg-secondary"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Mobile Mission Info */}
        <div className="md:hidden mt-4 flex items-center justify-between">
          <div className="font-mono text-lg text-primary font-bold">
            {formatMissionTime(missionTime)}
          </div>
          <div className="flex items-center gap-2">
            <span className={cn(
              'text-xs',
              orbitnetEnabled ? 'text-primary' : 'text-muted-foreground'
            )}>
              MESH
            </span>
            <Switch
              checked={orbitnetEnabled}
              onCheckedChange={onToggleOrbitnet}
              className="data-[state=checked]:bg-primary scale-75"
            />
          </div>
        </div>
      </div>
    </header>
  );
}
