import { TelemetryData } from '@/lib/simulation';
import { Satellite, Navigation, Thermometer, Fuel, Battery, MapPin, Clock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useEffect, useState } from 'react';

interface SatelliteMissionStateProps {
  telemetry: TelemetryData | null;
  isRunning: boolean;
  missionTime: number;
}

interface EmulatorInfo {
  emulator_enabled: boolean;
  emulator_demo_mode: boolean;
  emulator_packets_processed: number;
}

export function SatelliteMissionState({ telemetry, isRunning, missionTime }: SatelliteMissionStateProps) {
  const [emulatorInfo, setEmulatorInfo] = useState<EmulatorInfo | null>(null);

  // Fetch emulator info
  useEffect(() => {
    const fetchEmulatorInfo = async () => {
      try {
        const response = await fetch('http://localhost:8000/system/status');
        if (response.ok) {
          const data = await response.json();
          setEmulatorInfo({
            emulator_enabled: data.emulator_enabled || false,
            emulator_demo_mode: data.emulator_demo_mode || false,
            emulator_packets_processed: data.emulator_packets_processed || 0,
          });
        }
      } catch (error) {
        console.error('Failed to fetch emulator info:', error);
      }
    };

    fetchEmulatorInfo();
    const interval = setInterval(fetchEmulatorInfo, 2000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="card-glow bg-card rounded-lg border border-border p-6">
      {/* Header with Helper Text */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Satellite className="w-5 h-5 text-primary" />
          <h3 className="panel-header">Satellite & Mission State</h3>
          {emulatorInfo?.emulator_enabled && (
            <Badge variant={emulatorInfo.emulator_demo_mode ? "default" : "outline"} className="text-xs">
              {emulatorInfo.emulator_demo_mode ? "EMULATED" : "PHYSICS"}
            </Badge>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          Live position and health of the satellite generating data.
        </p>
      </div>

      {!telemetry ? (
        <div className="text-center py-8">
          <div className="w-12 h-12 rounded-full bg-muted animate-pulse mx-auto mb-3" />
          <div className="text-sm text-muted-foreground">Awaiting satellite telemetry...</div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Mission Status */}
          <div className="bg-secondary/30 rounded-lg p-4 border border-border/50">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">Mission Status</span>
              </div>
              <Badge variant={isRunning ? "default" : "secondary"}>
                {isRunning ? "RUNNING" : "STOPPED"}
              </Badge>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-muted-foreground mb-1">Mission Time</div>
                <div className="font-mono text-lg text-primary">{formatTime(missionTime)}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Data Packets</div>
                <div className="font-mono text-lg text-success">
                  {emulatorInfo?.emulator_packets_processed || 0}
                </div>
              </div>
            </div>
          </div>

          {/* Position & Navigation */}
          <div className="bg-secondary/30 rounded-lg p-4 border border-border/50">
            <div className="flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">Position & Navigation</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-muted-foreground mb-1">Altitude</div>
                <div className="flex items-baseline gap-1">
                  <span className="telemetry-value text-xl font-bold text-primary">
                    {telemetry.altitude.toFixed(1)}
                  </span>
                  <span className="text-xs text-muted-foreground">km</span>
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Velocity</div>
                <div className="flex items-baseline gap-1">
                  <span className="telemetry-value text-xl font-bold text-primary">
                    {telemetry.velocity.toFixed(2)}
                  </span>
                  <span className="text-xs text-muted-foreground">km/s</span>
                </div>
              </div>
              <div className="col-span-2">
                <div className="text-xs text-muted-foreground mb-1">Coordinates</div>
                <div className="font-mono text-sm text-primary">
                  {telemetry.position.lat.toFixed(4)}°, {telemetry.position.lng.toFixed(4)}°
                </div>
              </div>
            </div>
          </div>

          {/* Satellite Health */}
          <div className="bg-secondary/30 rounded-lg p-4 border border-border/50">
            <div className="flex items-center gap-2 mb-3">
              <Battery className="w-4 h-4 text-success" />
              <span className="text-sm font-medium">Satellite Health</span>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center">
                <Thermometer className={`w-5 h-5 mx-auto mb-1 ${
                  telemetry.temperature > 40 ? 'text-warning' : 'text-success'
                }`} />
                <div className="text-sm font-bold">
                  {telemetry.temperature.toFixed(1)}°C
                </div>
                <div className="text-xs text-muted-foreground">Temperature</div>
              </div>
              <div className="text-center">
                <Fuel className={`w-5 h-5 mx-auto mb-1 ${
                  telemetry.fuelLevel < 20 ? 'text-destructive' : 'text-success'
                }`} />
                <div className="text-sm font-bold">
                  {telemetry.fuelLevel.toFixed(1)}%
                </div>
                <div className="text-xs text-muted-foreground">Fuel</div>
              </div>
              <div className="text-center">
                <Battery className={`w-5 h-5 mx-auto mb-1 ${
                  telemetry.batteryLevel < 30 ? 'text-warning' : 'text-success'
                }`} />
                <div className="text-sm font-bold">
                  {telemetry.batteryLevel.toFixed(1)}%
                </div>
                <div className="text-xs text-muted-foreground">Battery</div>
              </div>
            </div>
          </div>

          {/* Attitude */}
          <div className="bg-secondary/30 rounded-lg p-4 border border-border/50">
            <div className="flex items-center gap-2 mb-3">
              <Navigation className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">Attitude Control</span>
            </div>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <div className="text-xs text-muted-foreground mb-1">Pitch</div>
                <div className="telemetry-value text-sm font-mono">
                  {telemetry.orientation.pitch.toFixed(2)}°
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Yaw</div>
                <div className="telemetry-value text-sm font-mono">
                  {telemetry.orientation.yaw.toFixed(2)}°
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Roll</div>
                <div className="telemetry-value text-sm font-mono">
                  {telemetry.orientation.roll.toFixed(2)}°
                </div>
              </div>
            </div>
          </div>

          {/* Packet Info */}
          <div className="pt-3 border-t border-border/50">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Current Packet ID</span>
              <span className="font-mono text-primary/70">{telemetry.dataPacketId}</span>
            </div>
            <div className="flex justify-between text-xs mt-1">
              <span className="text-muted-foreground">Last Update</span>
              <span className="font-mono text-primary/70">
                {new Date(telemetry.timestamp).toISOString().slice(11, 23)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}