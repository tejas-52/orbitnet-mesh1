import { useEffect, useState } from 'react';
import { Shield, Package, Send, AlertTriangle, CheckCircle2, Clock, Database } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface SystemStatus {
  system_mode: string;
  telemetry_generated: number;
  telemetry_sent: number;
  telemetry_buffered: number;
  telemetry_lost: number;
  current_link: string;
}

interface StoredPacket {
  id: string;
  timestamp: number;
  data: any;
}

export function DataHandlingSafety() {
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [storedPackets, setStoredPackets] = useState<StoredPacket[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        // Get system status
        const systemResponse = await fetch('http://localhost:8000/system/status');
        if (systemResponse.ok) {
          const systemData = await systemResponse.json();
          setSystemStatus(systemData);
        }

        // Get stored packets
        const packetsResponse = await fetch('http://localhost:8000/api/packets/stored');
        if (packetsResponse.ok) {
          const packetsData = await packetsResponse.json();
          setStoredPackets(packetsData.packets || []);
        }

        setError(null);
      } catch (err) {
        setError('Connection lost');
      }
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 2000);
    return () => clearInterval(interval);
  }, []);

  const getDataSafetyStatus = () => {
    if (!systemStatus) return null;

    const totalGenerated = systemStatus.telemetry_generated;
    const dataLossRate = totalGenerated > 0 ? (systemStatus.telemetry_lost / totalGenerated) * 100 : 0;
    const deliveryRate = totalGenerated > 0 ? (systemStatus.telemetry_sent / totalGenerated) * 100 : 0;

    if (systemStatus.system_mode === 'ORBITNET') {
      return {
        status: 'safe',
        icon: Shield,
        label: '100% Data Safety',
        description: 'Zero data loss guaranteed by ORBITNET-MESH',
        color: 'text-success',
        bg: 'bg-success/10',
        border: 'border-success/20',
        dataLossRate: 0,
        deliveryRate: deliveryRate
      };
    }

    if (dataLossRate === 0) {
      return {
        status: 'safe',
        icon: CheckCircle2,
        label: 'Data Safe',
        description: 'No data loss detected',
        color: 'text-success',
        bg: 'bg-success/10',
        border: 'border-success/20',
        dataLossRate: 0,
        deliveryRate: deliveryRate
      };
    }

    if (dataLossRate < 5) {
      return {
        status: 'mostly_safe',
        icon: AlertTriangle,
        label: 'Mostly Safe',
        description: 'Minor data loss detected',
        color: 'text-warning',
        bg: 'bg-warning/10',
        border: 'border-warning/20',
        dataLossRate: dataLossRate,
        deliveryRate: deliveryRate
      };
    }

    return {
      status: 'at_risk',
      icon: AlertTriangle,
      label: 'Data at Risk',
      description: 'Significant data loss occurring',
      color: 'text-destructive',
      bg: 'bg-destructive/10',
      border: 'border-destructive/20',
      dataLossRate: dataLossRate,
      deliveryRate: deliveryRate
    };
  };

  if (error) {
    return (
      <div className="card-glow bg-card rounded-lg border border-border p-6">
        <div className="flex items-center gap-2 mb-4">
          <Package className="w-5 h-5 text-muted-foreground" />
          <h3 className="panel-header">Data Handling & Safety</h3>
        </div>
        <div className="text-sm text-muted-foreground">{error}</div>
      </div>
    );
  }

  if (!systemStatus) {
    return (
      <div className="card-glow bg-card rounded-lg border border-border p-6">
        <div className="flex items-center gap-2 mb-4">
          <Package className="w-5 h-5 text-muted-foreground" />
          <h3 className="panel-header">Data Handling & Safety</h3>
        </div>
        <div className="text-sm text-muted-foreground">Loading data safety status...</div>
      </div>
    );
  }

  const safetyStatus = getDataSafetyStatus();
  if (!safetyStatus) return null;

  const StatusIcon = safetyStatus.icon;

  return (
    <div className="card-glow bg-card rounded-lg border border-border p-6">
      {/* Header with Helper Text */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Package className="w-5 h-5 text-primary" />
          <h3 className="panel-header">Data Handling & Safety</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Explains what the system does with data when communication is lost.
        </p>
      </div>

      {/* Safety Status */}
      <div className={cn(
        'rounded-lg p-4 border mb-6',
        safetyStatus.bg,
        safetyStatus.border
      )}>
        <div className="flex items-center gap-3 mb-3">
          <div className={cn('p-2 rounded-full bg-background/50')}>
            <StatusIcon className={cn('w-5 h-5', safetyStatus.color)} />
          </div>
          <div>
            <div className={cn('font-medium', safetyStatus.color)}>
              {safetyStatus.label}
            </div>
            <div className="text-xs text-muted-foreground">
              {safetyStatus.description}
            </div>
          </div>
        </div>

        {/* Data Loss Rate */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-muted-foreground">Data Delivery Rate</span>
            <span className={cn('font-medium', safetyStatus.color)}>
              {safetyStatus.deliveryRate.toFixed(1)}%
            </span>
          </div>
          <Progress 
            value={safetyStatus.deliveryRate} 
            className="h-2"
          />
        </div>
      </div>

      {/* Data Flow Statistics */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-secondary/30 rounded-lg p-4 border border-border/50">
          <div className="flex items-center gap-2 mb-2">
            <Database className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground uppercase tracking-wide">
              Generated
            </span>
          </div>
          <div className="text-lg font-bold text-primary">
            {systemStatus.telemetry_generated}
          </div>
          <div className="text-xs text-muted-foreground">
            📊 Total data packets created
          </div>
        </div>

        <div className="bg-secondary/30 rounded-lg p-4 border border-border/50">
          <div className="flex items-center gap-2 mb-2">
            <Send className="w-4 h-4 text-success" />
            <span className="text-xs text-muted-foreground uppercase tracking-wide">
              Delivered
            </span>
          </div>
          <div className="text-lg font-bold text-success">
            {systemStatus.telemetry_sent}
          </div>
          <div className="text-xs text-muted-foreground">
            ✅ Successfully transmitted to ground
          </div>
        </div>
      </div>

      {/* Buffer Status */}
      <div className="space-y-4">
        <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
          <div className="flex items-center gap-2 mb-3">
            <Package className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">Store-and-Forward Buffer</span>
            <Badge variant={systemStatus.telemetry_buffered > 0 ? "default" : "secondary"}>
              {systemStatus.telemetry_buffered > 0 ? 'Active' : 'Empty'}
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-muted-foreground mb-1">Packets Buffered</div>
              <div className="text-xl font-bold text-primary">
                {systemStatus.telemetry_buffered}
              </div>
              <div className="text-xs text-muted-foreground">
                📦 Data stored safely during blackout
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">Data Lost</div>
              <div className={cn('text-xl font-bold', 
                systemStatus.telemetry_lost === 0 ? 'text-success' : 'text-destructive'
              )}>
                {systemStatus.telemetry_lost}
              </div>
              <div className="text-xs text-muted-foreground">
                {systemStatus.system_mode === 'ORBITNET' 
                  ? '🛡️ Zero loss guaranteed' 
                  : '⚠️ Lost during blackouts'
                }
              </div>
            </div>
          </div>
        </div>

        {/* System Mode Explanation */}
        <div className="bg-secondary/20 rounded-lg p-3 border border-border/30">
          <div className="text-xs text-muted-foreground mb-2">How it works:</div>
          <div className="text-sm">
            {systemStatus.system_mode === 'ORBITNET' ? (
              <>
                <strong>ORBITNET-MESH Mode:</strong> When communication is unavailable, 
                data is stored safely and sent later. No data is ever lost.
              </>
            ) : (
              <>
                <strong>Ground-Only Mode:</strong> Data can only be sent when ground 
                stations are available. Data is lost during communication blackouts.
              </>
            )}
          </div>
        </div>

        {/* Current Status */}
        <div className="flex items-center justify-between text-xs pt-3 border-t border-border/50">
          <span className="text-muted-foreground">Current Communication</span>
          <div className="flex items-center gap-2">
            <div className={cn('w-2 h-2 rounded-full', 
              systemStatus.current_link === 'NONE' ? 'bg-destructive animate-pulse' : 'bg-success'
            )} />
            <span className={cn('font-medium',
              systemStatus.current_link === 'NONE' ? 'text-destructive' : 'text-success'
            )}>
              {systemStatus.current_link === 'NONE' ? 'Blackout - Data Being Stored' : 'Link Active - Data Flowing'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}