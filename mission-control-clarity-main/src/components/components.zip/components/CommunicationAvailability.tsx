import { useEffect, useState } from 'react';
import { Radio, Satellite, AlertTriangle, CheckCircle2, Clock, Zap } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface LinkStatus {
  link_type: string;
  available: boolean;
  name: string;
  signal_strength?: number;
  elevation_angle?: number;
  timestamp: number;
}

interface SystemStatus {
  satellite_visible: boolean;
  ground_visible: boolean;
  current_link: string;
  emulator_enabled?: boolean;
  emulator_demo_mode?: boolean;
}

export function CommunicationAvailability() {
  const [linkStatus, setLinkStatus] = useState<LinkStatus | null>(null);
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        // Get link status
        const linkResponse = await fetch('http://localhost:8000/api/link/status');
        if (linkResponse.ok) {
          const linkData = await linkResponse.json();
          setLinkStatus(linkData);
        }

        // Get system status
        const systemResponse = await fetch('http://localhost:8000/system/status');
        if (systemResponse.ok) {
          const systemData = await systemResponse.json();
          setSystemStatus(systemData);
        }

        setError(null);
      } catch (err) {
        setError('Connection lost');
      }
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 2000);
    return () => clearInterval(interval);
  }, []);

  const getCommunicationStatus = () => {
    if (!linkStatus || !systemStatus) return null;

    if (systemStatus.current_link === 'NONE') {
      return {
        status: 'blackout',
        icon: AlertTriangle,
        label: 'Communication Blackout',
        description: 'No communication links available',
        color: 'text-destructive',
        bg: 'bg-destructive/10',
        border: 'border-destructive/20'
      };
    }

    if (systemStatus.current_link === 'GROUND') {
      return {
        status: 'ground',
        icon: Radio,
        label: 'Ground Link Active',
        description: 'Direct communication with ground station',
        color: 'text-success',
        bg: 'bg-success/10',
        border: 'border-success/20'
      };
    }

    if (systemStatus.current_link === 'SATELLITE') {
      return {
        status: 'satellite',
        icon: Satellite,
        label: 'Satellite Relay Active',
        description: 'Communication via satellite relay',
        color: 'text-primary',
        bg: 'bg-primary/10',
        border: 'border-primary/20'
      };
    }

    return {
      status: 'partial',
      icon: Clock,
      label: 'Partial Coverage',
      description: 'Limited communication availability',
      color: 'text-warning',
      bg: 'bg-warning/10',
      border: 'border-warning/20'
    };
  };

  if (error) {
    return (
      <div className="card-glow bg-card rounded-lg border border-border p-6">
        <div className="flex items-center gap-2 mb-4">
          <Radio className="w-5 h-5 text-muted-foreground" />
          <h3 className="panel-header">Communication Availability</h3>
        </div>
        <div className="text-sm text-muted-foreground">{error}</div>
      </div>
    );
  }

  if (!linkStatus || !systemStatus) {
    return (
      <div className="card-glow bg-card rounded-lg border border-border p-6">
        <div className="flex items-center gap-2 mb-4">
          <Radio className="w-5 h-5 text-muted-foreground" />
          <h3 className="panel-header">Communication Availability</h3>
        </div>
        <div className="text-sm text-muted-foreground">Loading communication status...</div>
      </div>
    );
  }

  const commStatus = getCommunicationStatus();
  if (!commStatus) return null;

  const StatusIcon = commStatus.icon;

  return (
    <div className="card-glow bg-card rounded-lg border border-border p-6">
      {/* Header with Helper Text */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Radio className="w-5 h-5 text-primary" />
          <h3 className="panel-header">Communication Availability</h3>
        </div>
        <p className="text-xs text-muted-foreground">
          Shows whether the satellite can send data right now.
        </p>
      </div>

      {/* Current Status */}
      <div className={cn(
        'rounded-lg p-4 border mb-6',
        commStatus.bg,
        commStatus.border
      )}>
        <div className="flex items-center gap-3 mb-3">
          <div className={cn('p-2 rounded-full bg-background/50')}>
            <StatusIcon className={cn('w-5 h-5', commStatus.color)} />
          </div>
          <div>
            <div className={cn('font-medium', commStatus.color)}>
              {commStatus.label}
            </div>
            <div className="text-xs text-muted-foreground">
              {commStatus.description}
            </div>
          </div>
        </div>

        {/* Link Details */}
        {linkStatus.available && (
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-muted-foreground">Link Type:</span>
              <div className="font-medium capitalize">{linkStatus.link_type}</div>
            </div>
            <div>
              <span className="text-muted-foreground">Link Name:</span>
              <div className="font-medium">{linkStatus.name}</div>
            </div>
            {linkStatus.signal_strength && (
              <div>
                <span className="text-muted-foreground">Signal Strength:</span>
                <div className="font-medium">{linkStatus.signal_strength.toFixed(1)} dB</div>
              </div>
            )}
            {linkStatus.elevation_angle && (
              <div>
                <span className="text-muted-foreground">Elevation:</span>
                <div className="font-medium">{linkStatus.elevation_angle.toFixed(1)}°</div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Link Availability Grid */}
      <div className="space-y-3">
        <div className="text-xs text-muted-foreground uppercase tracking-wide mb-3">
          Available Links
        </div>

        <div className="grid grid-cols-2 gap-3">
          {/* Ground Link */}
          <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg border border-border/50">
            <div className="flex items-center gap-2">
              <Radio className={cn('w-4 h-4', 
                systemStatus.ground_visible ? 'text-success' : 'text-muted-foreground'
              )} />
              <span className="text-sm">Ground Link</span>
            </div>
            <Badge variant={systemStatus.ground_visible ? "default" : "secondary"}>
              {systemStatus.ground_visible ? 'Available' : 'Not Available'}
            </Badge>
          </div>

          {/* Satellite Relay */}
          <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg border border-border/50">
            <div className="flex items-center gap-2">
              <Satellite className={cn('w-4 h-4', 
                systemStatus.satellite_visible ? 'text-primary' : 'text-muted-foreground'
              )} />
              <span className="text-sm">Satellite Relay</span>
            </div>
            <Badge variant={systemStatus.satellite_visible ? "default" : "secondary"}>
              {systemStatus.satellite_visible ? 'Available' : 'Not Available'}
            </Badge>
          </div>
        </div>

        {/* Emulator Status */}
        {systemStatus.emulator_enabled && (
          <div className="mt-4 p-3 bg-primary/5 rounded-lg border border-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">Satellite Link Emulator</span>
              <Badge variant={systemStatus.emulator_demo_mode ? "default" : "outline"} className="text-xs">
                {systemStatus.emulator_demo_mode ? 'DEMO' : 'PHYSICS'}
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground">
              {systemStatus.emulator_demo_mode 
                ? "Simulating satellite communication delays for demonstration"
                : "Emulating real satellite physics and delays"
              }
            </div>
          </div>
        )}
      </div>

      {/* Status Chips */}
      <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-border/50">
        <Badge 
          variant={commStatus.status === 'blackout' ? "destructive" : "outline"}
          className="text-xs"
        >
          {commStatus.status === 'blackout' ? '🔴' : '🟢'} 
          {commStatus.status === 'blackout' ? 'Not Available' : 'Available'}
        </Badge>
        
        {commStatus.status !== 'blackout' && (
          <Badge variant="outline" className="text-xs">
            {commStatus.status === 'ground' ? '📡' : '🛰️'} 
            {commStatus.status === 'ground' ? 'Ground' : 'Satellite'}
          </Badge>
        )}

        {systemStatus.emulator_enabled && (
          <Badge variant="outline" className="text-xs">
            ⚙️ Emulated
          </Badge>
        )}
      </div>
    </div>
  );
}